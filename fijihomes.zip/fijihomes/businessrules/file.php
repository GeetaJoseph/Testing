<?php
class File{
  private $id;
  private $dates;
  private $times;
  private $epc;
  private $hex;
  private $antenna;
  
  public function __construct(){}
  
  public function __get($var){
    switch ($var){
      case 'id':
        return $this->id;
        break;
      case 'dates':
        return $this->dates;
        break;
      case 'times':
        return $this->times;
        break;
	  case 'epc':
		return $this->epc;
		break;
	  case 'hex':
		return $this->hex;
		break;
	  case 'antenna':
		return $this->antenna;
		break;
      default:
        return null;
        break;
    }
  }
  public function setid($var){
    $this->id = $var;
  }
  public function setdates($var){
    $this->dates = $var;
  }
  public function settimes($var){
    $this->times = $var;
  }
  public function setepc($var){
    $this->epc = $var;
  }
  public function sethex($var){
    $this->hex = $var;
  }
  public function setantenna($var){
    $this->antenna = $var;
  }
  
}
?>