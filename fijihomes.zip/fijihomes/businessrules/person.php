<?php
class Person{
  private $_fname;
  private $_lname;
  private $_contact;
   
 /* public function __construct(DALQueryResult $result){
    $this->_fname = $result->fname;
    $this->_lname = $result->lname;
    $this->_contact = $result->contact;
  }*/
  
  public function __construct($a,$b,$c){
    $this->_fname = $a;
    $this->_lname = $b;
    $this->_contact = $c;
  }
  public function __get($var){
    switch ($var){
      case 'fname':
        return $this->_fname;
        break;
      case 'lname':
        return $this->_lname;
        break;
      case 'contact':
        return $this->_contact;
        break;
      default:
        return null;
        break;
    }
  }
  public function __toString(){
    return $this->_fname;
  }
}
?>