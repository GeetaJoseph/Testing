<?php
include 'header1.php';
include 'o_header.php';
include 'header2.php';

echo "this page will display the owners property along with contact information of the agents and tenants";
include 'footer.php';
?>