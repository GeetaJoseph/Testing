</div>
</div>
</div>
<footer class="footer bg-info">
  <div class="container">
	<span class="text-muted">Place sticky footer content here.</span>
  </div>
</footer>
  </body>
</html>