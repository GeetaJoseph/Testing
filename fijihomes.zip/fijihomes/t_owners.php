<?php
include 'header1.php';
include 't_header.php';
include 'header2.php';

echo "This is owners page";
include 'footer.php';
?>