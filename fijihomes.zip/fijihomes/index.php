<?php
include 'header1.php';
include 'header2.php';

include 'home.php';
	/*$servername = "localhost";
	$username = "root";
	$password = "";
	$base = "fijihomesdb";
	
	$conn = new mysqli($servername, $username, $password, $base);
	
	// Check connection
	if ($conn->connect_error) {
		echo "connection failed";
		die("Connection failed: " . $conn->connect_error);
	}
	else{
		echo "the database is connected";
	}*/
	
	
include 'footer.php';
?>