	<li class="nav-item">
        <a class="nav-link" href="m_agents.php">Agents</a>
    </li>
	<li class="nav-item">
        <a class="nav-link" href="m_owners.php">Owners</a>
    </li>
	<li class="nav-item">
        <a class="nav-link" href="m_tenants.php">Tenants</a>
    </li>