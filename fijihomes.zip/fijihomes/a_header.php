	<li class="nav-item">
        <a class="nav-link" href="a_owners.php">Owners</a>
    </li>
	<li class="nav-item">
        <a class="nav-link" href="a_tenants.php">Tenants</a>
    </li>