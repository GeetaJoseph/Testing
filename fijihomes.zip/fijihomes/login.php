<?php
include 'header1.php';
include 'header2.php';
include 'dataaccesslayer/DAL.php';
?>
<form class ="form-group" method = "post">
<div class = "col-md-6 offset-md-1">
	<p>User Name<input type ="text" class ="form-control" name ="username" required/></p>
	<p>Password<input type ="password" class ="form-control" name ="password" required/></p>
	<input type="submit" name ="login" value="LOGIN"/>
</div>
</form>

<?php
if(isset($_POST['login'])){
	if($_POST['username'] == 'team'){
		if($_POST['password'] ==  "manager"){//after using DB, need to use switch cases to chose the domain
			$dal = new DAL();
			$result = $dal->trying('team','manager');
			header('Location: m_main.php');
			exit;
		}
		if($_POST['password'] ==  "agent"){//after using DB, need to use switch cases to chose the domain
			header('Location: a_main.php');
			exit;
		}
		if($_POST['password'] ==  "owner"){//after using DB, need to use switch cases to chose the domain
			header('Location: o_main.php');
			exit;
		}
		if($_POST['password'] ==  "tenant"){//after using DB, need to use switch cases to chose the domain
			header('Location: t_main.php');
			exit;
		}
		else{?>
		<p class= "text-center"><font color= "red" size =4>The password is incorrect<br/></font></p>
		<?php
		}
	}
	else{?>
		<p class= "text-center"><font color= "red" size =4>The username is incorrect<br/></font></p>
		<?php
	}
}
echo "its working";
include 'footer.php';
?>