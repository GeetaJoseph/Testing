	</ul>
	<ul class="navbar-nav p-2">
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Account
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="login.php">Sign In</a>
          <a class="dropdown-item" href="#">Create Account</a>
        </div>
      </li>
      </ul>
  </div>
</nav>
<div class="container bg-secondary" style="height:550px;">
<div class="row">
<div class="col-md-8 offset-md-2">