	<li class="nav-item">
        <a class="nav-link" href="t_property.php">Property</a>
    </li>
	<li class="nav-item">
        <a class="nav-link" href="t_owners.php">Owner</a>
    </li>