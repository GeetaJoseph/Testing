<?php
include 'header1.php';
include 'm_header.php';
include 'header2.php';

include 'home.php';
echo "its working";
include 'footer.php';
?>