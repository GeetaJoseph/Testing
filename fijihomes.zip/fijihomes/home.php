<?php
echo "This is home page and where the background image and the search function will go";
?>