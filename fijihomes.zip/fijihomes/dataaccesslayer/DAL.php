<?php
//require_once($_SERVER['DOCUMENT_ROOT'] .'/tut/inc/class/person.php');
//require_once($_SERVER['DOCUMENT_ROOT'] .'/tut/inc/class/file.php');
//include "../businessrule/person.php";

class DALQueryResult {
     
  private $_results = array();
	
  public function __construct(){}
 
  public function __set($var,$val){
	$this->_results[$var] = $val;
  }
 
  public function __get($var){  
	if (isset($this->_results[$var])){
	  return $this->_results[$var];
	}
	else{
	  return null;
	}
  }
}
 
class DAL {
 
  public function __construct(){}
   
  public function get_models_by_make_name($name){
    $sql = "SELECT models.id as id, models.name as name, makes.name as make FROM models INNER JOIN makes ON models.make=makes.id WHERE makes.name='$name'";
    return $this->query($sql);
  }
  
	public function displayall(){
		$query = "SELECT* FROM workers";
		return $this->query($query);		
	}
	public function trying($a, $b){
		$query = "INSERT INTO access (Email, Password) VALUES ('$a','$b')";
		return $this->query($query);
	}
	
	public function insert_apartments($a, $b, $c, $d,$e){
		$query = "INSERT INTO apartments (P_Address, Rooms, Max_People, Amenities, images) VALUES ('$a','$b','$c','$d','$e')";
		return $this->query($query);
	}
	
	public function displayImages(){
		$query = "SELECT images FROM apartments WHERE Rooms = 1";
		return $this->query($query);
	}
	
	public function searchid($id){
		$query = "SELECT* FROM workers WHERE empid = '$id'";
		return $this->query($query);
	}
	
	public function seasdkjfhdsk($id){
		$query = "SELECT* FROM workers WHERE empid = '$id'";
		return $this->query($query);
	}
	
	public function delete($id){
		$query = "DELETE FROM workers WHERE empid = '$id'";
		return $this->query($query);
	}
	
	public function update(Person $person,$id){
		$query1 = "UPDATE workers SET empfname = '$person->fname', emplname = '$person->lname', empcontact = '$person->contact' where empid = '$id'";
		return $this->query($query1);
	}
	
	public function insert(Person $person){
		$query = "INSERT INTO workers VALUES ('$person->fname','$person->lname','$person->contact')";
		return $this->query($query);
	}
	
	public function readfile($id,$name,$l){//".date("h:i:s")."
		date_default_timezone_set('Pacific/Fiji');
		$t =date("h:i:sa");
		$d =date("m/d/Y");
		$query = "INSERT INTO test2 VALUES ('$id','$t','$name','$d','$l')";
		return $this-> query($query);
	}
	
	public function readfinal($id,$d,$t,$long,$small,$short){
		$query = "INSERT INTO record VALUES ('$id','$d','$t','$long','$small','$short')";
		return $this-> query($query);
	}
	
	public function readfinal1(File $file){
		$query = "INSERT INTO record VALUES ('$file->id','$file->dates','$file->times','$file->epc','$file->hex','$file->antenna')";
		return $this-> query($query);
	}
	
	public function me(){
		echo "you are working hard";
	}
   
  private function dbconnect() {
	$servername = "localhost";
	$username = "root";
	$password = "";
	$base = "fijihomesdb";
	
	$conn = new mysqli($servername, $username, $password, $base);
	
     
    return $conn;
  }
   
  private function query($sql){
 
    $res = mysqli_query($this->dbconnect(),$sql);
 
    if ($res){
      if (strpos($sql,'SELECT') === false){
        return true;
      }
    }
    else{
      if (strpos($sql,'SELECT') === false){
        return false;
      }
      else{
        return null;
      }
    }
 
    $results = array();
 
    while ($row = mysqli_fetch_array($res)){
 
      $result = new DALQueryResult();
 
      foreach ($row as $k=>$v){
        $result->$k = $v;
      }
 
      $results[] = $result;
    }
    return $results;        
  }  
}
/*class DAL{
	public function _construct(){}
	
	private function dbconnect(){
		$conn = pg_connect(DB_HOST, DB_DB, DB_USER, DB_PASSWORD);
		return $conn;
	}
	
	public function display(){
		$query = "SELECT* FROM workers";
		$result = pg_query(this->dbconnect(),$query);
		
	}
	public function me(){
		echo "you are working hard";
	}
	
}*/
?>