<?php
include 'header1.php';
include 'a_header.php';
include 'header2.php'; 
include 'dataaccesslayer/DAL.php';
$dal = new DAL();
?>
<div class="row" >

	<form method="POST" name="image_upload" enctype="multipart/form-data" >
		<div class="form-group">
			<label for="address">Plot Address</label>
			<input type="text" class="form-control" name="address" placeholder="Plot Address"/required>
		</div>
			<div class="form-group">
			<label for="rooms">Number of Rooms</label>
			<input type="text" class="form-control" name="rooms" placeholder="Number of Rooms"/required>
		</div>
		<div class="form-group">
			<label for="max_people">Maximum Number of People</label>
			<input type="text" class="form-control" name="max_people" placeholder="Maximum Number of People"/required>
		</div>
		<div class="form-group">
			<label for="amenities">Amenities Available</label>
			<input type="text" class="form-control" name="amenities" placeholder="Amenities Available"/required>
		</div>
		<div class="form-group">
			<label for="image">Insert Images</label>
			<input type="file" class="form-control-file" name="image"/required>
		</div>
		<p><button type="submit" name = "upload" class="btn btn-primary">Upload..</button></p>
	</form>

</div>
	
<?php
	if(isset($_POST['upload']) ){
		$a = $_POST['address'];
		$b = $_POST['rooms'];
		$c = $_POST['max_people'];
		$d = $_POST['amenities'];
		$e = addslashes(file_get_contents($_FILES['image']['tmp_name']));
		//echo $a." ".$b." ".$c." ".$d." ".$e;
		$result1 = $dal->insert_apartments($a, $b, $c, $d, $e);

		//$result = $dal->displayImages();
		//$row = $result;
		//echo '<img src="data:image/jpeg;base64,'.base64_encode( $row[0]->images ).'"/>' ;
	}

?>

<?php
include 'footer.php';
?>

