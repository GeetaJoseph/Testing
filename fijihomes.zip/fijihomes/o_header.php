	<li class="nav-item">
        <a class="nav-link" href="o_property.php">Property</a>
    </li>
	<li class="nav-item">
        <a class="nav-link" href="o_tenants.php">Tenants</a>
    </li>